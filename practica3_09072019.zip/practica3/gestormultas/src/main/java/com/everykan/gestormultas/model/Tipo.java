package com.everykan.gestormultas.model;

public enum Tipo {
	LEVE, GRAVE, MUY_GRAVE;
}
