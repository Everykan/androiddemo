package com.everykan.fragmentshelloworld;

public interface ComunicaMenu {

        // recibe un parámetro que indica qué se ha pulsado

        // boton 0
        // boton 1
        // boton 2

        // estos botones estarán en un Array .. cómo se verá

        public void menu(int botonPulsado);

}
